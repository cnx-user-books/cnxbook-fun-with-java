//34567890123456789012345678901234567890123456789
//Note: this is wide format for small fonts.
//=============================================//

/*File Biomorph01.java Copyright 2004,R.G.Baldwin
Revised 4/8/04

The purpose of this program is to compute and
display the first nine stages of growth for a
Biomorph based on a simple gene set where each of
the seven genes that control the shape of the
Biomorph have a fixed value of 1.

This program is loosely based on material in
Chapter 8 of the book entitled Windows Hothouse
by Mark Clarkson.  However, it was necessary for
me to find and fix several typographical errors
in the C++ algorithm presented in that book.

Tested using J2SE 1.4.2 under WinXP.
************************************************/

import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Biomorph01{
  //Store the genes here.  The first seven genes
  // control the shape of the Biomorph.  The
  // eighth gene specifies the number of stages
  // used to construct the Biomorph.
  static double[] genes = new double[8];

  //This random number generator is required by
  // the Biomorph constructor, but isn't used for
  // any purpose in this program.
  static Random rGen =
                new Random(new Date().getTime());

  public static void main(String[] args){
    //Create 7 fixed gene values.
    for(int cnt = 0; cnt < 7; cnt++){
      genes[cnt]=1;
    }//end for
    //Specify the number of stages in the first
    // Biomorph object.
    genes[7] = 1;
    //Instantiate the GUI
    new GUI(genes,rGen);
  }//end main

}//end class Biomorph01

//=============================================//

//The following class is used to instantiate a
// graphical user interface object that causes
// the first nine stages of a Biomorph object to
// be created and displayed in nine grid cells in
// a Frame object.
class GUI extends Frame{
  Random rGen;
  double[] genes;

  //Constructor
  public GUI(double[] genes,Random rGen){
    //Save incoming parameters in local
    // variables.
    this.rGen = rGen;
    this.genes = genes;

    //Subdivide the Frame into nine grid cells.
    setLayout(new GridLayout(3,3));

    //Create and display nine stages of growth
    // for a Biomorph object using the same genes
    // for each stage.  Specify the third
    // parameter value to be negative to prevent
    // the Biomorph constructor from mutating the
    // genes.
    for(int cnt = 0; cnt < 9; cnt++){
      Biomorph biomorph =
                        new Biomorph(genes,
                                     rGen,
                                     -1,
                                     genes[7]/8,
                                     66,
                                     66);
      //Cause the background colors of the
      // Biomorph objects to alternate between
      // yellow and green so that they will be
      // visually separable in the Frame.
      if(cnt%2 == 0){
        biomorph.setBackground(Color.YELLOW);
      }else{
        biomorph.setBackground(Color.GREEN);
      }//end else

      //Add the Biomorph object to the Frame in
      // the next grid cell.
      this.add(biomorph);

      //Increase the number of stages for the
      // next Biomorph object.
      genes[7] += 1;
    }//end for loop

    setTitle("Copyright 2004, R.G.Baldwin");
    setSize(400,400);
    setVisible(true);

    //Instantiate and register a Listener object
    // that will terminate the program when the
    // user closes the Frame
    addWindowListener(
      new WindowAdapter(){
        public void windowClosing(WindowEvent e){
          System.exit(0);
        }//end windowClosing
      }//end WindowAdapter
    );//end addWindowListener
  }//end constructor

}//end class GUI definition
//=============================================//

//This class is used to instantiate a Biomorph
// object.  It is based loosely on Chapter 8 of
// the book entitled Windows Hothouse by Mark
// Clarkson.  However, the C++ algorithm
// presented in that book contains several
// serious typographical errors.  It was
// necessary for me to find and fix those errors
// when writing a Java version of the algorithm.
//The constructor receives an array of eight gene
// values. The final value in the array specifies
// the number of stages to be used to construct
// the Biomorph object.  The first stage produces
// a single stem.  Each successive stage causes
// all existing stems to bifurcate into two new
// stems.  Thus, the number of stems increases as
// a power of two based on the number of stages.
// For example, a Biomorph created with two
// stages contains three stems.  A three-stage
// Biomorph contains seven stems, a four-stage
// Biomorph contains fifteen stems, etc.
//When writing the Java version of the algorithm,
// I elected to maintain all of the data as type
// double in order to preserve arithmetic
// accuracy.  Values are converted from double to
// int at the very last step before displaying
// the Biomorph on the screen.
//The constructor receives a random number
// generator and a count value that are used to
// mutate a gene in the array of genes by a
// random value of plus or minus one whenever the
// count value is within the range from 0 to 7.
// If the count value is outside this range,
// there is no gene mutation.
//A method named getGenes returns the gene array
// containing the possibly mutated gene.  This is
// useful for experiments in selective breeding.
//The constructor receives a scale factor that is
// used to adjust the overall size of the plot to
// cause it to fit in the allocated plotting
// area.  Generally speaking, the size of the raw
// display of the Biomorph object would increase
// as the number of stages increases.  Therefore,
// it is useful to cause the scale factor to vary
// inversely with the number of stages.
//The constructor receives a pair of int values
// that are used to move the plotting origin
// from the default upper-left corner to another
// location in the plotting area.
//The direction of the first stem displayed for
// the Biomorph object is hard-coded to be
// vertical going up the screen, starting at the
// origin.
class Biomorph extends Panel{
  double[] xInc = new double[8];
  double[] yInc = new double[8];
  double[] genes;
  double xCoor = 0;//Start drawing here
  double yCoor = 0;//Start drawing here
  int direction = 0;//Initial drawing direction
  double length;
  double scale;
  int xOrigin;
  int yOrigin;

  //Constructor
  Biomorph(double[] genes,Random rGen,int cnt,
           double scale,int xOrigin,int yOrigin){

    //Save local copies of incoming parameters.
    this.genes = (double[])genes.clone();
    this.scale = scale;
    this.xOrigin = xOrigin;
    this.yOrigin = yOrigin;

    //Mutate gene at position cnt unless cnt is
    // out of the range from 0 through 7
    // inclusive.
    if((cnt>=0) && (cnt<=7)){
      double mutantValue = rGen.nextInt(2)*2-1;
      this.genes[cnt] += mutantValue;
      //Don't allow the eighth gene to go
      // negative
      if(this.genes[7] < 0)this.genes[7] = 0;
    }//end if

    //Compute incremental ends of lines based on
    // gene values.  Note that the C++ algorithm
    // presented in the Clarkson book appears to
    // contain several errors at this point.
    // Either that, or perhaps I don't fully
    // understand his version of the algorithm.
    xInc[0] =  0;
                        yInc[0] =  this.genes[0];
    xInc[1] =  this.genes[1];
                        yInc[1] =  this.genes[2];
    xInc[2] =  this.genes[3];
                        yInc[2] =  0;
    xInc[3] =  this.genes[4];
                        yInc[3] = -this.genes[5];
    xInc[4] =  0;
                        yInc[4] = -this.genes[6];
    xInc[5] = -this.genes[4];
                        yInc[5] = -this.genes[5];
    xInc[6] = -this.genes[3];
                        yInc[6] =  0;
    xInc[7] = -this.genes[1];
                        yInc[7] =  this.genes[2];


    //Initial line length is based on the number
    // of stages to be drawn.  Line length is
    // reduced by one as each successive stage is
    // drawn.  Algorithm terminates when length
    // reaches zero.
    length = this.genes[7];
  }//end constructor

  double[] getGenes(){
    return this.genes;
  }//end getGenes

  //Override the paint method
  public void paint(Graphics g){
    //Adjust location of the plotting origin
    g.translate(xOrigin,yOrigin);
    //Draw the Biomorph object recursively
    drawIt(g,xCoor,yCoor,length,direction,xInc,
                                     yInc,scale);
  }//end paint()
  //-------------------------------------------//

  void drawIt(Graphics g,double oldX,
              double oldY,double len,int newDir,
              double[] xInc,double[] yInc,
              double scale){
    //Direction values are limited to the range
    // from 0 to 7.
    newDir = (newDir + 8)%8;

    //Compute the end points of the line to be
    // drawn based ultimately on the values in
    // the gene array.
    double newX = oldX + len * xInc[newDir];
    double newY = oldY + len * yInc[newDir];

    //Draw the line.  Correct for the fact that
    // the default direction for positive y is
    // down the screen.
    g.drawLine((int)(oldX/scale),
               (int)(-oldY/scale),
               (int)(newX/scale),
               (int)(-newY/scale));

    //Continue drawing lines recursively until
    // the length of the next line reaches zero.
    // Decrease the length of the line by one for
    // each successive stage.  The values for
    // newX and newY become the incoming oldX and
    // oldY values for the next recursion.  Don't
    // waste time trying to draw a line with zero
    // length.
    if(len > 1){
      drawIt(g,newX,newY,len-1,newDir+1,xInc,
             yInc,scale);
      drawIt(g,newX,newY,len-1,newDir-1,xInc,
             yInc,scale);
    }//end if
  }//end drawIt

}//end class Biomorph
//=============================================//