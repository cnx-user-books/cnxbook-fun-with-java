//34567890123456789012345678901234567890123456789
//Note: this is wide format for small fonts.
//=============================================//

/*File Biomorph03.java Copyright 2004,R.G.Baldwin
Revised 04/08/04

This program falls in the general category of
Artificial Life.  The program models
an experiment in the evolutionary concept of
artificial selection as opposed to natural
selection.  For example, the variety of plants,
animals, and birds that exist on on uninhabited
island represent natural selection, sometimes
referred to as survival of the fittest.

A dalmation dog, on the other hand, is probably
the result of artificial selection. In other
words, over a long period of time, people
selected certain dogs for breeding to accentuate
certain characteristics (such as black spots on a
white coat) and to suppress other characteristics
(such as a long red coat).  Over time, what
resulted was a type of dog that we know as the
dalmation dog.  Although those who did that may
not have known that those characteristics were
represented by genes that were accentuated or
suppressed through selective breeding, we know
(or at least believe) that to be the case now.

This program makes it possible for you to
selectively breed successive generations of
artificial creatures known as Biomorph objects.
A single parent in one generation produces eight
offspring in the next generation.

Each Biomorph object is a recursively branching
tree consisting of many limbs of different
lengths that branch off in different directions.
Each such Biomorph object has eight genes that
control the size,the number, and the angle of the
branches.

During the creation of each new generation, one
of the genes for each of the eight offspring is
randomly mutated to produce a creature that is
similar to, but different from its parent.  You
can select one of the offspring from each
generation to become the parent of the next
generation in order to accentuate certain
characteristics and to suppress other
characteristics.  By continuing this process
through a large number of generations, you can
cause the resulting Biomorph objects to resemble
birds, bugs, animals, airplanes,human faces, or
whatever strikes your fancy.

The parent for each generation is displayed as
the ninth Biomorph object.  If you don't like any
of the eight offspring of that parent, you can
select it again and cause it to produce eight
more offspring based on random mutations of the
genes.

This program is loosely based on Chapter 8 of the
book entitled Windows Hothouse by Mark Clarkson.
That chapter was based on a book and a paper
published by Richard Dawkins.  The book was
entitled The Blind Watchmaker.  The paper was
entitled The Evolution of Evolvability and
appeared in the book entitled Artificial Life.

Tested using J2SE 1.4.2 under WinXP.
************************************************/

import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Biomorph03 implements MouseListener{
  static double[] genes = new double[8];
  static GUI gui;
  static MouseListener listener;
  static Random rGen = new Random(
                           new Date().getTime());

  public static void main(String[] args){
    //An object of this class is a mouse listener
    listener = new Biomorph03();

    //Create initial set of genes.
    for(int cnt = 0; cnt < 7; cnt++){
      genes[cnt] = 1.0;
    }//end for

    //Establish the initial number of stages that
    // will be used to create the first
    // generation of Biomorph objects.  This
    // value, which is contained in the ninth
    // gene can increase or decrease due to
    // mutation of the genes.  If it goes to
    // zero, that Biomorph object will disappear.
    // It is not allowed to go negative.
    genes[7] = 5;

    //Instantiate a new GUI object.
    gui = new GUI(genes,listener,rGen);
  }//end main

  //Define a MouseEvent handler to handle mouse
  // clicks on Biomorph objects.  The mouse is
  // used to select one of nine Biomorph objects
  // to become the parent of the next generation.
  public void mouseClicked(MouseEvent e){
    //Identify the specific Biomorph object that
    // was selected with the mouse.  Get and save
    // the mutated gene array belonging to that
    // object.  This will be the gene array of
    // the parent of the next generation.
    Biomorph theMorph =
                       (Biomorph)(e.getSource());
    genes = theMorph.getGenes();

    //Dispose of the existing GUI object in
    // preparation for creating a new one.
    gui.dispose();

    //Instantiate a new GUI object based on the
    // mutated gene array obtained from the
    // Biomorph object that was selected.
    gui = new GUI(genes,listener,rGen);
  }//end mouseClicked

  //Define remaining methods of the MouseListener
  // interface as empty methods.
  public void mousePressed(MouseEvent e){};
  public void mouseReleased(MouseEvent e){};
  public void mouseEntered(MouseEvent e){};
  public void mouseExited(MouseEvent e){};

}//end class Biomorph03
//=============================================//

//The following class is used to instantiate a
// graphical user interface object that displays
// none Biomorph objects in a 3x3 grid.
class GUI extends Frame{
  Random rGen;
  Biomorph[] morphs = new Biomorph[9];
  double[] genes;

  //Constructor
  public GUI(double[] genes,
             MouseListener listener,
             Random rGen){
    //Save incoming parameters.
    this.rGen = rGen;
    this.genes = genes;

    //Subdivide the GUI into nine grid cells of
    // equal size.
    setLayout(new GridLayout(3,3));

    //Instantiate nine Biomorph objects.  Add
    // them to the GUI.  They are placed in the
    // grid cells in the GUI from left to right,
    // top to bottom.
    //Register a mouse listener on each Biomorph
    // object.  Set the background color for each
    // Biomorph object to produce alternating
    // green and yellow backgrounds.
    for(int cnt = 0; cnt < 9; cnt++){
      //Instantiate and save a new Biomorph
      // object.  Set the origin to be the center
      // of the grid cell.
      morphs[cnt] = new Biomorph(genes,
                                 rGen,
                                 cnt,
                                 genes[7]/8,
                                 66,
                                 66);

      //Add this Biomorph object to the Frame in
      // the next grid cell.
      this.add(morphs[cnt]);

      //Register a mouse listener on the Biomorph
      // object.
      morphs[cnt].addMouseListener(listener);

      //Cause the background colors of the
      // Biomorph objects to alternate between
      // yellow and green so that they will be
      // visually separable in the Frame.
      if(cnt%2 == 0){
        morphs[cnt].setBackground(Color.YELLOW);
      }else{
        morphs[cnt].setBackground(Color.GREEN);
      }//end else
    }//end for loop

    //Finish the GUI and make it visible.
    setTitle("Copyright 2004, R.G.Baldwin");
    setSize(400,400);
    setVisible(true);

    //Instantiate and register a Listener object
    // that will terminate the program when the
    // user closes the Frame
    addWindowListener(
      new WindowAdapter(){
        public void windowClosing(WindowEvent e){
          System.exit(0);
        }//end windowClosing
      }//end WindowAdapter
    );//end addWindowListener
  }//end constructor

}//end class GUI definition
//=============================================//

//This class is used to instantiate a Biomorph
// object.  It is based loosely on Chapter 8 of
// the book entitled Windows Hothouse by Mark
// Clarkson.  However, the C++ algorithm
// presented in that book contains several
// serious typographical errors.  It was
// necessary for me to find and fix those errors
// when writing a Java version of the algorithm.
//The constructor receives an array of eight gene
// values. The final value in the array specifies
// the number of stages to be used to construct
// the Biomorph object.  The first stage produces
// a single stem.  Each successive stage causes
// all existing stems to bifurcate into two new
// stems.  Thus, the number of stems increases as
// a power of two based on the number of stages.
// For example, a Biomorph created with two
// stages contains three stems.  A three-stage
// Biomorph contains seven stems, a four-stage
// Biomorph contains fifteen stems, etc.
//When writing the Java version of the algorithm,
// I elected to maintain all of the data as type
// double in order to preserve arithmetic
// accuracy.  Values are converted from double to
// int at the very last step before displaying
// the Biomorph on the screen.
//The constructor receives a random number
// generator and a count value that are used to
// mutate a gene in the array of genes by a
// random value of plus or minus one whenever the
// count value is within the range from 0 to 7.
// If the count value is outside this range,
// there is no gene mutation.
//A method named getGenes returns the gene array
// containing the possibly mutated gene.  This is
// useful for experiments in selective breeding.
//The constructor receives a scale factor that is
// used to adjust the overall size of the plot to
// cause it to fit in the allocated plotting
// area.  Generally speaking, the size of the raw
// display of the Biomorph object would increase
// as the number of stages increases.  Therefore,
// it is useful to cause the scale factor to vary
// inversely with the number of stages.
//The constructor receives a pair of int values
// that are used to move the plotting origin
// from the default upper-left corner to another
// location in the plotting area.
//The direction of the first stem displayed for
// the Biomorph object is hard-coded to be
// vertical going up the screen, starting at the
// origin.
class Biomorph extends Panel{
  double[] xInc = new double[8];
  double[] yInc = new double[8];
  double[] genes;
  double xCoor = 0;//Start drawing here
  double yCoor = 0;//Start drawing here
  int direction = 0;//Initial drawing direction
  double length;
  double scale;
  int xOrigin;
  int yOrigin;

  //Constructor
  Biomorph(double[] genes,Random rGen,int cnt,
           double scale,int xOrigin,int yOrigin){

    //Save local copies of incoming parameters.
    this.genes = (double[])genes.clone();
    this.scale = scale;
    this.xOrigin = xOrigin;
    this.yOrigin = yOrigin;

    //Mutate gene at position cnt unless cnt is
    // out of the range from 0 through 7
    // inclusive.
    if((cnt>=0) && (cnt<=7)){
      double mutantValue = rGen.nextInt(2)*2-1;
      this.genes[cnt] += mutantValue;
      //Don't allow the eighth gene to go
      // negative
      if(this.genes[7] < 0)this.genes[7] = 0;
    }//end if

    //Compute incremental ends of lines based on
    // gene values.  Note that the C++ algorithm
    // presented in the Clarkson book appears to
    // contain several errors at this point.
    // Either that, or perhaps I don't fully
    // understand his version of the algorithm.
    xInc[0] =  0;
                        yInc[0] =  this.genes[0];
    xInc[1] =  this.genes[1];
                        yInc[1] =  this.genes[2];
    xInc[2] =  this.genes[3];
                        yInc[2] =  0;
    xInc[3] =  this.genes[4];
                        yInc[3] = -this.genes[5];
    xInc[4] =  0;
                        yInc[4] = -this.genes[6];
    xInc[5] = -this.genes[4];
                        yInc[5] = -this.genes[5];
    xInc[6] = -this.genes[3];
                        yInc[6] =  0;
    xInc[7] = -this.genes[1];
                        yInc[7] =  this.genes[2];


    //Initial line length is based on the number
    // of stages to be drawn.  Line length is
    // reduced by one as each successive stage is
    // drawn.  Algorithm terminates when length
    // reaches zero.
    length = this.genes[7];
  }//end constructor

  double[] getGenes(){
    return this.genes;
  }//end getGenes

  //Override the paint method
  public void paint(Graphics g){
    //Adjust location of the plotting origin
    g.translate(xOrigin,yOrigin);
    //Draw the Biomorph object recursively
    drawIt(g,xCoor,yCoor,length,direction,xInc,
                                     yInc,scale);
  }//end paint()
  //-------------------------------------------//

  void drawIt(Graphics g,double oldX,
              double oldY,double len,int newDir,
              double[] xInc,double[] yInc,
              double scale){
    //Direction values are limited to the range
    // from 0 to 7.
    newDir = (newDir + 8)%8;

    //Compute the end points of the line to be
    // drawn based ultimately on the values in
    // the gene array.
    double newX = oldX + len * xInc[newDir];
    double newY = oldY + len * yInc[newDir];

    //Draw the line.  Correct for the fact that
    // the default direction for positive y is
    // down the screen.
    g.drawLine((int)(oldX/scale),
               (int)(-oldY/scale),
               (int)(newX/scale),
               (int)(-newY/scale));

    //Continue drawing lines recursively until
    // the length of the next line reaches zero.
    // Decrease the length of the line by one for
    // each successive stage.  The values for
    // newX and newY become the incoming oldX and
    // oldY values for the next recursion.  Don't
    // waste time trying to draw a line with zero
    // length.
    if(len > 1){
      drawIt(g,newX,newY,len-1,newDir+1,xInc,
             yInc,scale);
      drawIt(g,newX,newY,len-1,newDir-1,xInc,
             yInc,scale);
    }//end if
  }//end drawIt

}//end class Biomorph
//=============================================//